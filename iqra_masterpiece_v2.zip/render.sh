#!/usr/bin/env bash
set -e
npm install
bash setup-linux.sh
npm run render
npm run thumb || true
ls -lh out/
