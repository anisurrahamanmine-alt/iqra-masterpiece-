#!/usr/bin/env bash
# Serves out/ on port 8080 so you can open the link in a browser tab and download video.mp4
cd "$(dirname "$0")/out" || { echo "out/ folder nei - age npm run render chalan"; exit 1; }
echo "Open: http://localhost:8080  (Codespaces: PORTS tab -> 8080 -> globe icon)"
if command -v python3 >/dev/null 2>&1; then python3 -m http.server 8080; else npx --yes http-server -p 8080 .; fi
