import { interpolate, spring } from 'remotion';
import { easeIO } from './anim';
import { FPS } from './config';

// Continuous virtual camera: [frame, scale]. Alternating slow zoom-in / zoom-out, creeping push-ins on suspense.
const KEYS: [number, number][] = [
  [0, 1.28], [14, 1.0], [130, 1.04], [150, 1.06], [245, 1.0],      // S1 punch-in, drift, chart pull-out
  [252, 1.0], [262, 1.06], [488, 1.12],                             // S2 snap on "কিন্তু" + creeping push-in
  [512, 1.0], [700, 1.1], [708, 1.08], [745, 1.0], [770, 1.0],      // S3 tension push -> climax settle
  [840, 1.03], [862, 1.0], [1066, 1.05],                            // S4 thinker, grid zoom-in
  [1092, 1.0], [1530, 1.08],                                        // S5 slow push through checklist
  [1560, 1.0], [1600, 1.0], [1690, 1.07], [1830, 1.02],             // S6 reverent zoom-in on verse
  [2090, 1.07], [2190, 1.0],                                        // S7 push then pull-out to reveal depth
  [2200, 1.0], [2410, 1.05],                                        // S8 upward build
  [2440, 1.0], [2700, 1.04],                                        // S9
  [2716, 1.0], [2845, 1.06],                                        // S10 uplifting push-in
  [2880, 1.0], [3080, 1.03],                                        // S11
];
// snappy punches on key reveals: [frame, amplitude]
const PUNCH: [number, number][] = [[256, 0.03], [427, 0.05], [706, 0.05], [1600, 0.025], [2207, 0.035], [2508, 0.03], [2781, 0.03], [2956, 0.02]];

export const cameraAt = (F: number) => {
  let s = 1;
  for (let i = 0; i < KEYS.length - 1; i++) {
    const [a, sa] = KEYS[i], [b, sb] = KEYS[i + 1];
    if (F >= a && F <= b) { s = interpolate(F, [a, b], [sa, sb], { easing: easeIO }); break; }
    if (F > b) s = sb;
  }
  for (const [at, amp] of PUNCH) {
    if (F >= at && F < at + 40) {
      const up = spring({ frame: F - at, fps: FPS, config: { damping: 9, stiffness: 300, mass: 0.5 } });
      s += amp * up * Math.max(0, 1 - (F - at) / 40);
    }
  }
  const x = Math.sin(F / 95) * 10 + Math.sin(F / 41) * 3;
  const y = Math.cos(F / 120) * 7;
  return { s, x, y };
};
