import { useEffect, useState } from 'react';
import { continueRender, delayRender, staticFile } from 'remotion';

type Face = { family: string; file: string; weight: string; style?: string; range?: string };
const BN = 'U+0951-0952,U+0964-0965,U+0980-09FE,U+1CD0-1CF9,U+200C-200D,U+20B9,U+25CC,U+A8F1';
const LAT = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';
export const FACES: Face[] = [
  { family: 'Baloo Da 2 V', file: 'BalooDa2-800-bengali.woff2', weight: '800', range: BN },
  { family: 'Baloo Da 2 V', file: 'BalooDa2-800-latin.woff2', weight: '800', range: LAT },
  { family: 'Baloo Da 2 V', file: 'BalooDa2-700-bengali.woff2', weight: '700', range: BN },
  { family: 'Baloo Da 2 V', file: 'BalooDa2-700-latin.woff2', weight: '700', range: LAT },
  { family: 'Tatsam V', file: 'TatsamBengaliRnd-Bold.otf', weight: '700' },
  { family: 'Hind V', file: 'HindSiliguri-Medium.ttf', weight: '500' },
  { family: 'Hind V', file: 'HindSiliguri-SemiBold.ttf', weight: '600' },
  { family: 'Hind V', file: 'HindSiliguri-Bold.ttf', weight: '700' },
  { family: 'Tiro V', file: 'TiroBangla-Regular.ttf', weight: '400' },
  { family: 'Tiro V', file: 'TiroBangla-Italic.ttf', weight: '400', style: 'italic' },
  { family: 'Amiri Quran V', file: 'AmiriQuran-arabic.woff2', weight: '400' },
  { family: 'Amiri V', file: 'Amiri-700-arabic.woff2', weight: '700' },
];

let injected = false;
const injectCss = () => {
  if (injected || typeof document === 'undefined') return;
  injected = true;
  const css = FACES.map((f) => `@font-face{font-family:'${f.family}';src:url('${staticFile('fonts/' + f.file)}');font-weight:${f.weight};font-style:${f.style ?? 'normal'};font-display:block;${f.range ? `unicode-range:${f.range};` : ''}}`).join('\n');
  const el = document.createElement('style');
  el.textContent = css;
  document.head.appendChild(el);
};
const withTimeout = <T,>(p: Promise<T>, ms: number) => Promise.race([p, new Promise<void>((r) => setTimeout(r, ms))]);

export const useFonts = () => {
  const [handle] = useState(() => delayRender('fonts', { timeoutInMilliseconds: 120000 }));
  useEffect(() => {
    injectCss();
    Promise.all(
      FACES.map((f) =>
        withTimeout(
          new FontFace(f.family, `url('${staticFile('fonts/' + f.file)}')`, { weight: f.weight, style: f.style ?? 'normal', unicodeRange: f.range })
            .load()
            .then((l) => (document.fonts as any).add(l))
            .catch(() => {}),
          25000,
        ),
      ),
    ).then(() => continueRender(handle));
  }, [handle]);
};
