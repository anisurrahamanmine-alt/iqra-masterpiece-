// One place for aspect ratio, timing and scene boundaries (all frames @30fps, from word timings).
export const ASPECT: '9:16' | '16:9' = '9:16';
export const FPS = 30;
export const WIDTH = ASPECT === '9:16' ? 1080 : 1920;
export const HEIGHT = ASPECT === '9:16' ? 1920 : 1080;
export const AUDIO_SEC = 101.642;
export const DURATION = Math.ceil((AUDIO_SEC + 1) * FPS); // +1s end hold
export const OVERLAP = 12;
export const SAFE = { stageTop: 160, stageBottom: 1320, center: 720, capTop: 1380, capBottom: 1620, uiTop: 1660, side: 70, rightUi: 110, maxW: 880 };

export const SCENES = [
  { id: 1, from: 0, to: 252 },     // common assumption
  { id: 2, from: 252, to: 498 },   // pattern interrupt + question
  { id: 3, from: 498, to: 770 },   // solo climax: Iqra
  { id: 4, from: 770, to: 1080 },  // pause & reflect: 2x2
  { id: 5, from: 1080, to: 1543 }, // before any identity
  { id: 6, from: 1543, to: 1830 }, // sacred verse 96:1
  { id: 7, from: 1830, to: 2200 }, // depth layers
  { id: 8, from: 2200, to: 2418 }, // foundation pyramid
  { id: 9, from: 2418, to: 2704 }, // blind faith vs knowledge
  { id: 10, from: 2704, to: 2850 },// mission
  { id: 11, from: 2850, to: DURATION }, // finale
] as const;
export const sc = (id: number) => SCENES[id - 1];
