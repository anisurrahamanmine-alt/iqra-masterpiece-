import React from 'react';
import { easeIO, idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C } from '../theme';
import { Abs, Card } from '../components/Card';
import { HiraArt } from '../components/HiraArt';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SacredVerseCard } from '../components/SacredVerseCard';
import { SceneShell } from '../components/SceneShell';
import { TopLight } from '../components/Atmos';
import { CreationRow } from '../components/Creation';

const S = sc(6);
// cues: সর্বপ্রথমই 1541 · বললেন 1572 · اقْرَأْ 1600 · بِاسْمِ 1611 · رَبِّكَ 1624 · الَّذِي 1640 · خَلَقَ 1654 · অর্থাৎ 1671 · পড়ো 1697 · নামে 1754 · যিনি 1764 · করেছেন 1809
export const SFX06: SfxCue[] = [
  sx(1541, 'whoosh_cine2.mp3', 0.3), sx(1546, 'paper_slide.mp3', 0.34), sx(1548, 'pop_c.mp3', 0.2), sx(1552, 'shine.mp3', 0.18, 60),
  sx(1572, 'pop_a.mp3', 0.28), sx(1588, 'whoosh_c.mp3', 0.26), sx(1590, 'synth_chime_soft.wav', 0.16, 34),
  sx(1671, 'page_flip.mp3', 0.36), sx(1699, 'marker.mp3', 0.44), sx(1707, 'paper_slide.mp3', 0.34), sx(1758, 'whoosh_d.mp3', 0.2),
  sx(1764, 'pop_c.mp3', 0.24), sx(1768, 'twinkle.mp3', 0.26), sx(1780, 'synth_tick.wav', 0.3), sx(1788, 'synth_tick.wav', 0.3),
  sx(1796, 'synth_tick.wav', 0.3), sx(1816, 'page_turn.mp3', 0.55),
];

export const Scene06: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="pushUp" exit="fold" origin="540px 900px">
    {(F) => {
      const beam = ramp(F, 1548, 1590) * (0.85 + 0.15 * Math.sin(F / 14));
      const back = ramp(F, 1590, 1606, 0, 1, easeIO);
      const hp = sp(F, 1544, 'soft');
      return (
        <>
          <TopLight o={0.35 + 0.25 * ramp(F, 1590, 1620)} floorY={1260} width={900} />
          {/* framed gallery card: Cave Hira */}
          <Abs y={480 - 70 * back} style={{ opacity: lin(F, 1544, 1552) * (1 - 0.62 * back), filter: back > 0.01 ? `blur(${4 * back}px)` : undefined, transform: `translate(-50%, -50%) translateY(${80 * (1 - hp) + idle(F, 0, 3, 80)}px) scale(${(0.94 + 0.06 * hp) * (1 - 0.08 * back)})` }}>
            <Card w={880} pad={30}><HiraArt F={F} beam={beam} /></Card>
          </Abs>
          <Abs y={1000}>
            <KBlock gap={0}>
              <Small F={F} at={1546} exitAt={1590} text="সর্বপ্রথমই তিনি" size={64} />
              <Key F={F} at={1570} exitAt={1590} text="বললেন —" size={112} v="teal" />
            </KBlock>
          </Abs>
          {/* sacred verse card */}
          <Abs y={880 - 70 * ramp(F, 1758, 1772, 0, 1, easeIO)}>
            <SacredVerseCard F={F} at={1592} trAt={1671} sweepAt={1697} line2At={1762} citeAt={1705} />
          </Abs>
          {/* everything He created */}
          <Abs y={1252}>
            <CreationRow F={F} at={1768} step={4} />
          </Abs>
        </>
      );
    }}
  </SceneShell>
);
