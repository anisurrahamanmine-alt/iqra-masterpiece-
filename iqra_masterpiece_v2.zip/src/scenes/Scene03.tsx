import React from 'react';
import { AbsoluteFill } from 'remotion';
import { easeIO, idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C, FONT, SHADOW } from '../theme';
import { Abs } from '../components/Card';
import { Slash } from '../components/Icons';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';
import { TopLight } from '../components/Atmos';

const S = sc(3);
// cues: না 501 · ইবাদতের 525 · কথা 541 · না 554 · কঠিন 576 · নিয়ম 583 · আল্লাহর 604 · একদম 649 · ওয়ার্ডটাই 670 · ইকরা 706 · অর্থাৎ 727 · পড়ো 747
export const SFX03: SfxCue[] = [
  sx(501, 'pop_b.mp3', 0.32), sx(538, 'synth_slash.wav', 0.44), sx(556, 'pop_b.mp3', 0.3), sx(580, 'synth_slash.wav', 0.44),
  sx(590, 'whoosh_c.mp3', 0.34), sx(604, 'shine.mp3', 0.16, 70), sx(606, 'pop_c.mp3', 0.22), sx(651, 'synth_riser_soft.wav', 0.34),
  sx(652, 'marker.mp3', 0.42), sx(706, 'boom_suspense.mp3', 0.42), sx(708, 'synth_chime_soft.wav', 0.26), sx(747, 'impact_hit.mp3', 0.26, 40),
  sx(750, 'marker.mp3', 0.42), sx(752, 'shine.mp3', 0.2, 80),
];

const Chip: React.FC<{ F: number; at: number; slashAt: number; outAt: number; small: string; big: string; y: number }> = ({ F, at, slashAt, outAt, small, big, y }) => {
  const p = sp(F, at, 'pop');
  const o = ramp(F, outAt, outAt + 12, 0, 1, easeIO);
  return (
    <Abs y={y} style={{ opacity: lin(F, at, at + 6) * (1 - o), transform: `translate(-50%, -50%) translate(${900 * o}px, ${40 * (1 - p) + idle(F, y, 3, 50)}px) scale(${0.7 + 0.3 * p}) rotate(${-2 + 2 * p}deg)` }}>
      <div style={{ position: 'relative', display: 'flex', alignItems: 'baseline', gap: 18, padding: '22px 48px', whiteSpace: 'nowrap', borderRadius: 999, background: C.card, border: `1.5px solid ${C.hair}`, boxShadow: SHADOW.card }}>
        <span style={{ fontFamily: FONT.sans, fontWeight: 600, fontSize: 56, color: C.ink }}>{small}</span>
        <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 88, color: C.navy, lineHeight: 1.1 }}>{big}</span>
        <div style={{ position: 'absolute', left: 20, right: 20, top: '38%' }}><Slash w={620} h={40} p={ramp(F, slashAt, slashAt + 9)} sw={12} /></div>
      </div>
    </Abs>
  );
};

export const Scene03: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="zoomIn" exit="none">
    {(F) => {
      const veil = ramp(F, 604, 640);
      const light = ramp(F, 610, 700) * 0.45 + ramp(F, 700, 712) * 0.45;
      const flash = ramp(F, 704, 708) * (1 - ramp(F, 708, 726)) * 0.3;
      const ar = ramp(F, 699, 717);
      const ik = sp(F, 706, 'slam');
      const hd = ramp(F, 756, 780, 0, 1, easeIO);
      return (
        <>
          <AbsoluteFill style={{ background: C.card, opacity: veil * 0.62 }} />
          <TopLight o={light} floorY={1240} width={860} />
          <Chip F={F} at={501} slashAt={538} outAt={590} small="কোনো" big="ইবাদতের কথা" y={600} />
          <Chip F={F} at={556} slashAt={580} outAt={593} small="কোনো" big="কঠিন নিয়ম" y={820} />
          <Abs y={720}>
            <KBlock gap={4}>
              <Small F={F} at={604} exitAt={694} text="আল্লাহর তরফ থেকে আসা" size={64} />
              <Key F={F} at={649} exitAt={694} text="একদম প্রথম ওয়ার্ড" size={112} k="soft" />
            </KBlock>
          </Abs>
          {/* SOLO CLIMAX */}
          <AbsoluteFill style={{ opacity: 1 - lin(F, 766, 774), transform: `translateY(${-468 * hd}px) scale(${1 - 0.66 * hd})`, transformOrigin: '540px 716px' }}>
            <Abs y={470}>
              <div style={{ position: 'relative', opacity: lin(F, 699, 707) }}>
                <div style={{ position: 'absolute', left: -80, right: -80, top: 30, bottom: 10, borderRadius: '50%', background: `radial-gradient(ellipse at center, ${C.gold}aa, ${C.gold}00 70%)`, opacity: 0.8 + 0.2 * Math.sin(F / 10) }} />
                <div dir="rtl" lang="ar" style={{ unicodeBidi: 'embed', direction: 'rtl', position: 'relative', fontFamily: "'Amiri V', 'Amiri Quran V', serif", fontWeight: 700, fontSize: 190, lineHeight: 1.7, color: C.navy, clipPath: `inset(0 0 0 ${100 - ar * 100}%)`, textShadow: '0 6px 24px rgba(217,119,6,.25)' }}>اقْرَأْ</div>
              </div>
            </Abs>
            <Abs y={770}>
              <div style={{ opacity: lin(F, 706, 710), transform: `scale(${2.1 - 1.1 * ik})`, fontFamily: FONT.display, fontWeight: 800, fontSize: 200, lineHeight: 1.1, color: C.teal, textShadow: SHADOW.word }}>ইকরা</div>
            </Abs>
            <Abs y={975}>
              <Key F={F} at={747} text="পড়ো!" size={150} k="slam" underline />
            </Abs>
          </AbsoluteFill>
          <AbsoluteFill style={{ background: '#FFFFFF', opacity: flash }} />
          {/* dust drifting in the light */}
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} style={{ position: 'absolute', left: 420 + ((i * 53) % 240), top: 260 + ((i * 97 + F * (0.4 + (i % 3) * 0.2)) % 900), width: 5, height: 5, borderRadius: 3, background: '#E9C46A', opacity: light * 0.6 * (1 - hd) }} />
          ))}
        </>
      );
    }}
  </SceneShell>
);
