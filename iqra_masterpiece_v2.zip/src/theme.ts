// "Alabaster & Sapphire Illumination" — every colour and font role lives here.
export const C = {
  paper: '#FAF9F5',      // warm alabaster ivory base
  card: '#FFFEFA',       // elevated ivory cards
  ink: '#27303F',        // charcoal slate (connecting words)
  navy: '#141E30',       // midnight sapphire (key words, captions pill)
  navy2: '#22304B',
  gold: '#FDE68A',       // warm champagne gold highlight block
  goldDeep: '#D97706',   // burnished gold: borders/underlines/rings ONLY
  teal: '#0D9488',       // knowledge / truth / iqra
  tealSoft: '#CCFBF1',
  ruby: '#BE123C',       // misconception / ignorance
  rubySoft: '#FFE4E6',
  hair: '#E5E7EB',
  periwinkle: '#C7D2FE',
  mint: '#BFEFE3',
  champagne: '#FBE7B5',
  white: '#FFFFFF',
};
export const FONT = {
  display: "'Baloo Da 2 V', 'Tatsam V', 'Hind V', 'Noto Sans Bengali', sans-serif",
  sans: "'Hind V', 'Noto Sans Bengali', sans-serif",
  serif: "'Tiro V', 'Hind V', 'Noto Serif Bengali', serif",
  arabic: "'Amiri Quran V', 'Amiri V', 'Scheherazade New', serif",
};
export const SHADOW = {
  card: '0 2px 0 rgba(20,30,48,.04), 0 18px 40px rgba(20,30,48,.16)',
  soft: '0 10px 26px rgba(20,30,48,.12)',
  word: '0 3px 0 rgba(20,30,48,.10), 0 10px 24px rgba(20,30,48,.10)',
};
export const MOOD = 'soft-default'; // calm reverent base with selective springy accents
