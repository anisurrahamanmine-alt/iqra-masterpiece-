import React from 'react';
import { spring, useCurrentFrame } from 'remotion';
import { CHUNKS } from '../data/captions';
import { C, FONT } from '../theme';
import { FPS } from '../config';

/** one-line word-synced caption, fixed at y≈1500 (zone 1380–1620) */
export const KineticCaptionBar: React.FC = () => {
  const F = useCurrentFrame();
  let idx = -1;
  for (let i = 0; i < CHUNKS.length; i++) {
    const c = CHUNKS[i];
    const next = CHUNKS[i + 1];
    const holdTo = next && next.s - c.e < 20 ? next.s : c.e + 10;
    if (F >= c.s - 2 && F < holdTo) { idx = i; break; }
  }
  if (idx < 0) return null;
  const c = CHUNKS[idx];
  const p = spring({ frame: F - (c.s - 2), fps: FPS, config: { damping: 14, stiffness: 220, mass: 0.6 } });
  return (
    <div style={{ position: 'absolute', left: 0, right: 0, top: 1500, display: 'flex', justifyContent: 'center', transform: `translateY(-50%) translateY(${16 * (1 - p)}px) scale(${0.92 + 0.08 * p})`, opacity: Math.min(1, p * 1.5) }}>
      <div style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '16px 34px', borderRadius: 24, background: `linear-gradient(180deg, ${C.navy2}eb, ${C.navy}eb)`, border: `2px solid ${C.gold}55`, boxShadow: '0 14px 30px rgba(20,30,48,.28)', whiteSpace: 'nowrap', maxWidth: 900 }}>
        {c.words.map((w, i) => {
          const active = F >= w.s - 1 && F < (c.words[i + 1]?.s ?? c.e + 10);
          const past = F >= (c.words[i + 1]?.s ?? 1e9);
          return (
            <span key={i} style={{ fontFamily: FONT.sans, fontWeight: 700, fontSize: 56, lineHeight: 1.2, padding: '2px 12px', borderRadius: 12, background: active ? C.gold : 'transparent', color: active ? C.navy : past ? '#FFFFFF' : 'rgba(255,255,255,.45)', transform: active ? 'scale(1.04)' : undefined }}>
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};
