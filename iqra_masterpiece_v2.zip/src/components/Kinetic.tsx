import React from 'react';
import { lin, ramp, sp, out } from '../anim';
import { C, FONT, SHADOW } from '../theme';

type Base = { F: number; at: number; exitAt?: number; style?: React.CSSProperties };

/** small connecting words (Hind SemiBold, charcoal), popping word by word */
export const Small: React.FC<Base & { text: string; size?: number; color?: string; stagger?: number }> = ({ F, at, exitAt = 1e9, text, size = 56, color = C.ink, stagger = 3, style }) => {
  const o = out(F, exitAt, 10);
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0 0.28em', fontFamily: FONT.sans, fontWeight: 600, fontSize: size, lineHeight: 1.25, color, opacity: 1 - o, transform: `translateY(${-24 * o}px)`, ...style }}>
      {text.split(' ').map((w, i) => {
        const p = sp(F, at + i * stagger, 'pop');
        return <span key={i} style={{ display: 'inline-block', opacity: lin(F, at + i * stagger, at + i * stagger + 5), transform: `translateY(${30 * (1 - p)}px) scale(${0.6 + 0.4 * p})` }}>{w}</span>;
      })}
    </div>
  );
};

export type KeyVariant = 'gold' | 'ruby' | 'teal';
/** ONE key word/phrase per line: sapphire on champagne-gold block | ruby | teal (Baloo Da 2 ExtraBold) */
export const Key: React.FC<Base & { text: string; v?: KeyVariant; size?: number; k?: 'pop' | 'slam' | 'soft' | 'snap'; tilt?: number; underline?: boolean }> = ({ F, at, exitAt = 1e9, text, v = 'gold', size = 112, k = 'pop', tilt = 0, underline = false, style }) => {
  const p = sp(F, at, k);
  const o = out(F, exitAt, 10);
  const op = lin(F, at, at + 5) * (1 - o);
  const sweep = ramp(F, at + 3, at + 14);
  const s0 = k === 'slam' ? 2.0 : 0.55;
  const scale = s0 + (1 - s0) * p;
  const color = v === 'gold' ? C.navy : v === 'ruby' ? C.ruby : C.teal;
  const ul = ramp(F, at + 8, at + 26);
  return (
    <div style={{ position: 'relative', display: 'inline-block', opacity: op, transform: `translateY(${(k === 'slam' ? 0 : 40) * (1 - p) - 20 * o}px) scale(${scale}) rotate(${tilt * (1 - p * 0.6)}deg)`, ...style }}>
      {v === 'gold' && (
        <div style={{ position: 'absolute', left: -size * 0.16, right: -size * 0.16, top: size * 0.16, bottom: size * 0.06, background: C.gold, borderRadius: size * 0.16, transformOrigin: 'left center', transform: `scaleX(${sweep})`, boxShadow: '0 6px 18px rgba(217,119,6,.18)' }} />
      )}
      <span style={{ position: 'relative', fontFamily: FONT.display, fontWeight: 800, fontSize: size, lineHeight: 1.18, color, textShadow: SHADOW.word, whiteSpace: 'nowrap' }}>{text}</span>
      {underline && (
        <svg width="100%" height={size * 0.22} viewBox="0 0 100 10" preserveAspectRatio="none" style={{ position: 'absolute', left: 0, bottom: -size * 0.1, overflow: 'visible' }}>
          <path d="M2 6 Q 25 1 50 5 T 98 4" fill="none" stroke={C.goldDeep} strokeWidth={2.4} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ul} vectorEffect="non-scaling-stroke" style={{ strokeWidth: 7 }} />
        </svg>
      )}
    </div>
  );
};

/** centered column for kinetic lines */
export const KBlock: React.FC<{ children: React.ReactNode; gap?: number; style?: React.CSSProperties }> = ({ children, gap = 14, style }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap, maxWidth: 880, textAlign: 'center', ...style }}>{children}</div>
);

/** ivory backing pill for text that sits over artwork */
export const Pill: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <div style={{ background: 'rgba(255,254,250,.94)', borderRadius: 999, padding: '10px 34px', boxShadow: SHADOW.soft, ...style }}>{children}</div>
);
