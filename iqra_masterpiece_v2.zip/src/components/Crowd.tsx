import React from 'react';
import { idle, lin, out, sp } from '../anim';
import { C } from '../theme';
import { CharityHand, Crescent, Mosque } from './Icons';

const SHIRTS = ['#0D9488', '#3F5C8A', '#D9A441', '#6D7FD1', '#2E8B7E', '#C2566B', '#22304B', '#5FA8D3', '#8B6FC9'];
const SKINS = ['#C98E64', '#A9714B', '#D9A27C', '#B07A52'];

/** small flat person icon (whole-figure animation only) */
const Mini: React.FC<{ i: number; h: number }> = ({ i, h }) => {
  const shirt = SHIRTS[i % SHIRTS.length];
  const skin = SKINS[i % SKINS.length];
  const hijab = i % 3 === 1;
  const cap = i % 4 === 2;
  return (
    <svg width={h * 0.64} height={h} viewBox="0 0 64 100">
      <path d="M8 100 Q8 58 32 56 Q56 58 56 100Z" fill={shirt} />
      {hijab ? (
        <>
          <path d="M32 10 Q12 10 12 34 Q12 54 22 60 H42 Q52 54 52 34 Q52 10 32 10Z" fill={C.navy} />
          <ellipse cx={32} cy={34} rx={13} ry={15} fill={skin} />
        </>
      ) : (
        <>
          <circle cx={32} cy={34} r={17} fill={skin} />
          <path d="M15 32 Q15 14 32 14 Q49 14 49 30 Q40 22 28 24 Q20 26 15 32Z" fill={cap ? '#FFFFFF' : '#2B2220'} />
        </>
      )}
      <circle cx={26} cy={35} r={2.2} fill={C.navy} /><circle cx={38} cy={35} r={2.2} fill={C.navy} />
      <path d="M27 43 q5 4 10 0" stroke={C.navy} strokeWidth={2.2} fill="none" strokeLinecap="round" />
    </svg>
  );
};

const BUBBLES = [
  { who: 1, I: Mosque, c: C.navy },
  { who: 4, I: Crescent, c: C.teal },
  { who: 7, I: CharityHand, c: C.goldDeep },
];

/** "most people would say" — a row of people popping in, each idea pops as a speech bubble */
export const Crowd: React.FC<{ F: number; at: number; exitAt: number; bubbleAts: number[]; n?: number; h?: number }> = ({ F, at, exitAt, bubbleAts, n = 9, h = 108 }) => {
  const o = out(F, exitAt, 10);
  const w = h * 0.64;
  return (
    <div style={{ position: 'relative', display: 'flex', gap: 12, alignItems: 'flex-end', opacity: 1 - o, transform: `translateY(${40 * o}px)` }}>
      {Array.from({ length: n }).map((_, i) => {
        const t = at + i * 3;
        const p = sp(F, t, 'pop');
        const b = BUBBLES.find((x) => x.who === i);
        const bi = b ? BUBBLES.indexOf(b) : -1;
        const bp = bi >= 0 ? sp(F, bubbleAts[bi], 'pop') : 0;
        const talk = bi >= 0 && F >= bubbleAts[bi] && F < bubbleAts[bi] + 14 ? Math.sin((F - bubbleAts[bi]) / 2) * 4 : 0;
        return (
          <div key={i} style={{ position: 'relative', opacity: lin(F, t, t + 5), transform: `translateY(${30 * (1 - p) + idle(F, i, 2.5, 40 + i * 3) - Math.abs(talk)}px) scale(${0.5 + 0.5 * p})`, transformOrigin: 'bottom center' }}>
            <Mini i={i} h={h} />
            {b && (
              <div style={{ position: 'absolute', left: w / 2 - 34, top: -78, width: 68, height: 62, opacity: bp, transform: `scale(${bp})`, transformOrigin: 'bottom center' }}>
                <svg width={68} height={62} viewBox="0 0 68 62" style={{ position: 'absolute', inset: 0 }}>
                  <path d="M10 2 H58 Q66 2 66 10 V40 Q66 48 58 48 H40 L34 60 L28 48 H10 Q2 48 2 40 V10 Q2 2 10 2Z" fill="#FFFFFF" stroke={b.c} strokeWidth={3} />
                </svg>
                <div style={{ position: 'absolute', left: 16, top: 6 }}><b.I size={36} /></div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
