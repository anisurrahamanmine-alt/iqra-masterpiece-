import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { cameraAt } from '../camera';
import { SAFE } from '../config';

/** Three parallax planes: bg 0.3x, mid 1.0x, fg 1.25x of the virtual camera move. */
export const CameraRig: React.FC<{ layer: 'bg' | 'mid' | 'fg'; children: React.ReactNode }> = ({ layer, children }) => {
  const F = useCurrentFrame();
  const { s, x, y } = cameraAt(F);
  const k = layer === 'bg' ? 0.3 : layer === 'fg' ? 1.25 : 1;
  const scale = 1 + (s - 1) * k;
  return (
    <AbsoluteFill style={{ transform: `translate(${x * k}px, ${y * k}px) scale(${scale})`, transformOrigin: `540px ${SAFE.center}px` }}>
      {children}
    </AbsoluteFill>
  );
};
