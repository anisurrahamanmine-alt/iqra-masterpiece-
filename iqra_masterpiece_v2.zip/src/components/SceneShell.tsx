import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { easeIO, lin, ramp, sp } from '../anim';
import { OVERLAP } from '../config';

export type Enter = 'none' | 'fade' | 'pushUp' | 'fromRight' | 'fromLeft' | 'zoomIn' | 'unfold';
export type Exit = 'none' | 'fade' | 'toLeft' | 'toRight' | 'zoomThrough' | 'slideDown' | 'fold';

/** Wraps a scene: F (absolute frame) via render prop; ~12-frame overlapping motion hand-offs, never hard cuts. */
export const SceneShell: React.FC<{ from: number; to: number; enter?: Enter; exit?: Exit; origin?: string; children: (F: number) => React.ReactNode }> = ({ from, to, enter = 'fade', exit = 'fade', origin = '540px 720px', children }) => {
  const F = useCurrentFrame() + from;
  const e = enter === 'none' ? 1 : sp(F, from, 'soft');
  const eo = enter === 'none' ? 1 : lin(F, from, from + 8);
  const x = ramp(F, to - 2, to + OVERLAP, 0, 1, easeIO);
  let tf = '';
  let op = 1;
  switch (enter) {
    case 'pushUp': tf += `translateY(${260 * (1 - e)}px) `; op *= eo; break;
    case 'fromRight': tf += `translateX(${700 * (1 - e)}px) `; op *= eo; break;
    case 'fromLeft': tf += `translateX(${-700 * (1 - e)}px) `; op *= eo; break;
    case 'zoomIn': tf += `scale(${0.78 + 0.22 * e}) `; op *= eo; break;
    case 'unfold': tf += `perspective(1600px) rotateX(${28 * (1 - e)}deg) scale(${0.86 + 0.14 * e}) `; op *= eo; break;
    case 'fade': op *= eo; break;
  }
  switch (exit) {
    case 'toLeft': tf += `translateX(${-760 * x}px) `; op *= 1 - x * 0.9; break;
    case 'toRight': tf += `translateX(${760 * x}px) `; op *= 1 - x * 0.9; break;
    case 'zoomThrough': tf += `scale(${1 + 2.6 * x * x}) `; op *= 1 - x; break;
    case 'slideDown': tf += `translateY(${420 * x}px) `; op *= 1 - x; break;
    case 'fold': tf += `perspective(1600px) rotateX(${-30 * x}deg) scale(${1 - 0.25 * x}) `; op *= 1 - x; break;
    case 'fade': op *= 1 - x; break;
  }
  return <AbsoluteFill style={{ transform: tf || undefined, transformOrigin: origin, opacity: op }}>{children(F)}</AbsoluteFill>;
};
