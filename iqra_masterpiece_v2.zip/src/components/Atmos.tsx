import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { rnd } from '../anim';
import { C } from '../theme';

/** Soft top-down light cone + floor glow (never back-lit rays). */
export const TopLight: React.FC<{ o: number; x?: number; floorY?: number; width?: number; color?: string }> = ({ o, x = 540, floorY = 1180, width = 760, color = '#FFF3C4' }) => {
  const F = useCurrentFrame();
  const flick = 1 + Math.sin(F / 23) * 0.04;
  if (o <= 0.001) return null;
  return (
    <AbsoluteFill style={{ pointerEvents: 'none', opacity: o * flick }}>
      <div style={{ position: 'absolute', left: x - width / 2, top: 0, width, height: floorY, clipPath: `polygon(${width * 0.36}px 0, ${width * 0.64}px 0, 100% 100%, 0 100%)`, background: `linear-gradient(180deg, ${color}cc 0%, ${color}55 45%, ${color}00 100%)`, filter: 'blur(6px)' }} />
      <div style={{ position: 'absolute', left: x - width * 0.55, top: floorY - 90, width: width * 1.1, height: 180, borderRadius: '50%', background: `radial-gradient(ellipse at center, ${color}aa 0%, ${color}00 70%)` }} />
    </AbsoluteFill>
  );
};

/** gentle archival vignette on outer edges */
export const Vignette: React.FC<{ o: number }> = ({ o }) =>
  o <= 0.001 ? null : <AbsoluteFill style={{ pointerEvents: 'none', opacity: o, background: `radial-gradient(ellipse 75% 62% at 50% 42%, transparent 55%, ${C.navy}38 100%)` }} />;

/** foreground dust motes (fg parallax plane) */
export const DustMotes: React.FC<{ n?: number; o?: number }> = ({ n = 26, o = 1 }) => {
  const F = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: 'none', opacity: o }}>
      {Array.from({ length: n }).map((_, i) => {
        const x0 = rnd(i + 1) * 1080, y0 = rnd(i + 50) * 1700 + 80;
        const sp = 0.15 + rnd(i + 9) * 0.35;
        const y = ((y0 - F * sp) % 1700 + 1700) % 1700 + 80;
        const x = x0 + Math.sin((F + i * 40) / 60) * 14;
        const r = 1.5 + rnd(i + 3) * 3;
        return <div key={i} style={{ position: 'absolute', left: x, top: y, width: r * 2, height: r * 2, borderRadius: r, background: i % 3 === 0 ? C.goldDeep : C.navy, opacity: 0.1 + rnd(i + 7) * 0.14 }} />;
      })}
    </AbsoluteFill>
  );
};
