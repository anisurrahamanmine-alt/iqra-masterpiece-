import React from 'react';
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from 'remotion';
import { cameraAt } from '../camera';
import { C } from '../theme';
import { SCENES } from '../config';

// 8-point star lattice tile (rub el hizb style: two overlapping squares) + fine graph grid, always panning.
const Star = ({ cx, cy, r }: { cx: number; cy: number; r: number }) => {
  const sq = (rot: number) => {
    const pts = [0, 1, 2, 3].map((i) => {
      const a = (rot + i * 90) * Math.PI / 180;
      return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`;
    });
    return <polygon points={pts.join(' ')} fill="none" />;
  };
  return <g>{sq(0)}{sq(45)}<circle cx={cx} cy={cy} r={r * 0.42} fill="none" /></g>;
};

const WASH: [string, string, string][] = [
  [C.periwinkle, C.mint, C.champagne], [C.champagne, C.periwinkle, C.mint], [C.mint, C.champagne, C.periwinkle],
];

export const AnimatedGridBg: React.FC = () => {
  const F = useCurrentFrame();
  const cam = cameraAt(F);
  const k = 0.3;
  const sIdx = Math.max(0, SCENES.findIndex((s) => F >= s.from && F < s.to));
  const w = WASH[sIdx % 3];
  const wPrev = WASH[(sIdx + 2) % 3];
  const t = interpolate(F - SCENES[sIdx].from, [0, 18], [0, 1], { extrapolateRight: 'clamp' });
  const panX = (F * 0.35) % 200;
  const panY = (F * 0.18) % 200;
  const latX = (F * -0.22) % 240;
  const arc = F * 0.04;
  return (
    <AbsoluteFill style={{ background: C.paper, overflow: 'hidden' }}>
      <AbsoluteFill style={{ transform: `translate(${cam.x * k}px, ${cam.y * k}px) scale(${1 + (cam.s - 1) * k})` }}>
        {/* corner washes (cross-fade per scene) */}
        {[{ c: wPrev, o: 1 - t }, { c: w, o: t }].map((L, i) => (
          <AbsoluteFill key={i} style={{ opacity: L.o, background: `radial-gradient(circle at 8% 6%, ${L.c[0]}2e 0%, transparent 38%), radial-gradient(circle at 96% 48%, ${L.c[1]}26 0%, transparent 36%), radial-gradient(circle at 10% 96%, ${L.c[2]}30 0%, transparent 40%)` }} />
        ))}
        {/* fine graph grid */}
        <svg width={1400} height={2300} style={{ position: 'absolute', left: -160 - panX, top: -190 - panY }}>
          <defs>
            <pattern id="g40" width={40} height={40} patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke={C.navy} strokeOpacity={0.045} strokeWidth={1} /></pattern>
            <pattern id="g200" width={200} height={200} patternUnits="userSpaceOnUse"><rect width={200} height={200} fill="url(#g40)" /><path d="M200 0H0V200" fill="none" stroke={C.navy} strokeOpacity={0.07} strokeWidth={1.2} /><circle cx={0} cy={0} r={2.2} fill={C.navy} fillOpacity={0.12} /></pattern>
          </defs>
          <rect width={1400} height={2300} fill="url(#g200)" />
        </svg>
        {/* 8-point star lattice, very faint, slower opposite drift */}
        <svg width={1560} height={2400} style={{ position: 'absolute', left: -240 + latX, top: -240 }}>
          <defs>
            <pattern id="lat" width={240} height={240} patternUnits="userSpaceOnUse">
              <g stroke={C.teal} strokeOpacity={0.07} strokeWidth={1.3}><Star cx={120} cy={120} r={58} /><Star cx={0} cy={0} r={58} /><Star cx={240} cy={0} r={58} /><Star cx={0} cy={240} r={58} /><Star cx={240} cy={240} r={58} /></g>
            </pattern>
          </defs>
          <rect width={1560} height={2400} fill="url(#lat)" />
        </svg>
        {/* astrolabe compass arcs */}
        <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0 }}>
          <g transform={`translate(540 760) rotate(${arc})`} fill="none" stroke={C.goldDeep} strokeOpacity={0.09}>
            <circle r={620} strokeWidth={1.2} strokeDasharray="2 14" />
            <circle r={760} strokeWidth={1} />
            {Array.from({ length: 72 }).map((_, i) => (
              <line key={i} x1={0} y1={-760} x2={0} y2={i % 6 === 0 ? -728 : -744} transform={`rotate(${i * 5})`} strokeWidth={1.2} />
            ))}
          </g>
        </svg>
      </AbsoluteFill>
      <Img src={staticFile('img/grain.png')} style={{ position: 'absolute', inset: 0, width: 1080, height: 1920, objectFit: 'cover', opacity: 0.35, mixBlendMode: 'multiply' }} />
    </AbsoluteFill>
  );
};
