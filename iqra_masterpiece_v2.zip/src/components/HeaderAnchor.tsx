import React from 'react';
import { lin } from '../anim';
import { C, FONT, SHADOW } from '../theme';

/** small glowing "اقْرَأْ · ইকরা · পড়ো" anchor that Scene 3's climax glides into */
export const HeaderAnchor: React.FC<{ F: number; at: number; outAt: number }> = ({ F, at, outAt }) => (
  <div style={{ position: 'absolute', left: 540, top: 250, transform: `translate(-50%, -50%) translateY(${-14 * lin(F, outAt, outAt + 12)}px)`, opacity: lin(F, at + 1, at + 8) * (1 - lin(F, outAt, outAt + 12)) }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 22, padding: '10px 36px', borderRadius: 999, background: C.card, border: `2px solid ${C.goldDeep}66`, boxShadow: `${SHADOW.soft}, 0 0 40px ${C.gold}88` }}>
      <span dir="rtl" style={{ unicodeBidi: 'embed', fontFamily: "'Amiri V', serif", fontWeight: 700, fontSize: 64, lineHeight: 1.5, color: C.navy }}>اقْرَأْ</span>
      <span style={{ width: 2, height: 46, background: C.hair }} />
      <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 60, color: C.teal }}>ইকরা</span>
      <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 60, color: C.navy, background: C.gold, borderRadius: 12, padding: '0 14px' }}>পড়ো</span>
    </div>
  </div>
);
