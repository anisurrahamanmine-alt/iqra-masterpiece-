import React from 'react';
import { C, FONT } from '../theme';

/** trapezoid layer used by Scene 7 depth diagram and Scene 8 pyramid (shared for the morph hand-off) */
export const Tier: React.FC<{ x?: number; y: number; w: number; h: number; top?: number; fill: string; text: React.ReactNode; color?: string; size?: number; border?: string; glow?: number; style?: React.CSSProperties }> = ({ x = 540, y, w, h, top = 0.9, fill, text, color = '#FFFFFF', size = 54, border, glow = 0, style }) => {
  const inset = ((1 - top) / 2) * 100;
  return (
    <div style={{ position: 'absolute', left: x - w / 2, top: y - h / 2, width: w, height: h, filter: `drop-shadow(0 14px 24px rgba(20,30,48,.18))${glow > 0 ? ` drop-shadow(0 0 ${26 * glow}px ${C.gold})` : ''}`, ...style }}>
      <div style={{ position: 'absolute', inset: 0, clipPath: `polygon(${inset}% 0, ${100 - inset}% 0, 100% 100%, 0 100%)`, background: border ?? fill }} />
      {border && <div style={{ position: 'absolute', inset: 5, clipPath: `polygon(${inset}% 0, ${100 - inset}% 0, 100% 100%, 0 100%)`, background: fill }} />}
      <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FONT.display, fontWeight: 800, fontSize: size, color, whiteSpace: 'nowrap', lineHeight: 1 }}>{text}</div>
    </div>
  );
};
