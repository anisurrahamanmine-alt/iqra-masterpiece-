import React from 'react';
import { Composition } from 'remotion';
import { DURATION, FPS, HEIGHT, WIDTH } from './config';
import { Main } from './Video';

// Thumbnail = still of Main at the "ইকরা / পড়ো!" climax (npm run thumb)
export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={DURATION} fps={FPS} width={WIDTH} height={HEIGHT} />
);
