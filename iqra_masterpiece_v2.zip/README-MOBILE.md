# অ্যান্ড্রয়েড থেকে রেন্ডার (GitHub Codespaces)

১. GitHub-এ নতুন রিপো বানান → Code → Codespaces → Create codespace (৪-কোর মেশিন হলে দ্রুত হবে)।
২. বাঁ পাশের Explorer-এ ZIP আপলোড করুন।
৩. টার্মিনালে COMMANDS.txt-এর কমান্ডগুলো ক্রমানুসারে চালান।
৪. রেন্ডার শেষে out/video.mp4-এ রাইট-ক্লিক → Download। না হলে `npm run download` চালিয়ে PORTS ট্যাবে 8080-এর লিংক খুলে ডাউনলোড করুন।

রেন্ডার-সময়ের আন্দাজ: ২-কোরে ~১২–২০ মিনিট, ৪-কোরে ~৬–১০ মিনিট (১:৪৩ ভিডিও)।
বিকল্প: Actions ট্যাব → "Render video" → Run workflow → শেষ হলে Artifacts থেকে ডাউনলোড।
