# অ্যাসেট-সূত্র

| ফাইল | উৎস | লাইসেন্স | কোথায় |
|---|---|---|---|
| public/sfx/*.mp3 | ব্যবহারকারীর Sound_Effects_SFX.zip (ASCII নাম, -3 dB পিকে নরমালাইজ) | ব্যবহারকারীর | সব সিন |
| public/sfx/synth_*.wav | কোডে তৈরি (tools/synth_sfx.py) | নিজস্ব | নরম চাইম, টিক, স্ল্যাশ, রাইজার, সূর্যোদয়-সোয়েল |
| HindSiliguri, TiroBangla, TatsamBengaliRnd | ব্যবহারকারীর Fonts.zip | — | লেখা |
| BalooDa2-*.woff2 | npm @fontsource/baloo-da-2 (Google Fonts) | SIL OFL 1.1 | ডিসপ্লে শব্দ |
| AmiriQuran-arabic.woff2, Amiri-700-arabic.woff2 | npm @fontsource/amiri-quran, @fontsource/amiri | SIL OFL 1.1 | আরবি আয়াত |
| public/img/grain.png | কোডে তৈরি | নিজস্ব | কাগজের টেক্সচার |
